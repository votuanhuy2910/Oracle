﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using System.Data.OracleClient;
using Oracle.DataAccess;
using Oracle.DataAccess.Client;


namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            OracleConnection con = new OracleConnection();
            //OracleException: The provider is not compatible with the version of Oracle client
            //vs 4
            string chuoi = @"Data source= orcl;user id=system; password=12345678;";
            con.ConnectionString=chuoi;
            con.Open();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // hien du lieu
            OracleConnection con = new OracleConnection();
            // mo ket noi
            string chuoi = @"Data source= orcl;user id=system; password=12345678;";
            con.ConnectionString = chuoi;
            con.Open();
            // chay querry
            string query = "select * from abophan";
            OracleCommand cmd = new OracleCommand(query, con);
            //cmd.ExecuteNonQuery();
            DataTable result = new DataTable();
            OracleDataAdapter dapter = new OracleDataAdapter(cmd);
            dapter.Fill(result);

            // hien thi
            dataGridView1.DataSource = result;
        }
    }
}
