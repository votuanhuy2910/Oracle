﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess;
using Oracle.DataAccess.Client;


namespace WindowsFormsApp3
{
    public partial class frmnhanvien : Form
    {
        public frmnhanvien()
        {
            InitializeComponent();
        }
        DBUtils ac = new DBUtils();
        public void hien()
        {
            var dt = ac.GetDataTable_Text("SELECT * FROM ANHANVIEN");
            dataGridView1.DataSource = dt;
            //return dt;
        }
        public void them(string ten, string ghichu, string chucvu, string bophan, string ngaysinh, string gioitinh, string diachi, string dienthoai, string hoso)
        {
            string chuoi = " INSERT INTO ANHANVIEN ";
            chuoi += " (TEN,GHICHU,CHUCVU,BOPHAN,NGAYSINH,GIOITINH,DIACHI,DIENTHOAI,HOSO) ";
            chuoi += " VALUES ( ";
            chuoi += " N'" + ten + "',  ";
            chuoi += " N'" + ghichu + "',  ";
            chuoi += " N'" + chucvu + "',  ";
            chuoi += " N'" + bophan + "',  ";
            chuoi += " N'" + ngaysinh + "',  ";
            chuoi += " N'" + gioitinh + "',  ";
            chuoi += " N'" + diachi + "',  ";
            chuoi += " N'" + dienthoai + "',  ";
            chuoi += " N'" + hoso + "') ";
            try
            {
                ac.ExecuteCommandtext(chuoi);
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }
        public void sua(int id, string ten, string ghichu, string chucvu, string bophan, string ngaysinh, string gioitinh, string diachi, string dienthoai, string hoso)
        {
            string chuoi = " UPDATE  ANHANVIEN SET ";
            chuoi += " TEN= N'" + ten + "',  ";
            chuoi += " GHICHU= N'" + ghichu + "',  ";
            chuoi += " CHUCVU= N'" + chucvu + "',  ";
            chuoi += " BOPHAN= N'" + bophan + "',  ";
            chuoi += " NGAYSINH= N'" + ngaysinh + "',  ";
            chuoi += " GIOITINH= N'" + gioitinh + "',  ";
            chuoi += " DIACHI= N'" + diachi + "',  ";
            chuoi += " DIENTHOAI= N'" + dienthoai + "',  ";
            chuoi += " HOSO= N'" + hoso + "'  ";
            chuoi += " WHERE id = N'" + id + "' ";
            try
            {
                ac.ExecuteCommandtext(chuoi);
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }
        public void xoa(int id)
        {
            string chuoi = "DELETE  FROM ANHANVIEN   ";
            chuoi += " WHERE id = N'" + id + "' ";
            try
            {
                ac.ExecuteCommandtext(chuoi);
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }

        private void btnthem_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtten.Text == null)
                {
                    MessageBox.Show("Vui lòng nhập dữ liệu", "Thông báo!", MessageBoxButtons.OK);
                    txtten.Focus();
                    lblthongbao.Text = "Chưa có dữ liệu.";
                }
                else
                {
                    int id = int.Parse(txtma.Text);
                    string ten = txtten.Text;
                    string ghichu = txtghichu.Text;
                    string chucvu = cbchucvu.Text.ToString();
                    string bophan = cbbophan.Text.ToString();
                    string ngaysinh = txtngaysinh.Text;
                    string gioitinh = checkgioitinh();
                    string diachi = txtdiachi.Text;
                    string dienthoai = txtdienthoai.Text;
                    string hoso = txthoso.Text;

                    them(ten, ghichu, chucvu, bophan, ngaysinh, gioitinh, diachi, dienthoai, hoso);
                    hien();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex.ToString());
            }

        }

        private void btnhien_Click(object sender, EventArgs e)
        {
            hien();
            hien_bophan();
            hien_chucvu();
        }

        private void btnsua_Click(object sender, EventArgs e)
        {
            try
            {
                if (int.Parse(txtma.Text) <= 0)
                {
                    MessageBox.Show("Vui lòng chọn dữ liệu", "Thông báo!", MessageBoxButtons.OK);
                    lblthongbao.Text = "Chưa chọn dữ liệu.";
                }
                else
                {
                    int id = int.Parse(txtma.Text);
                    string ten = txtten.Text;
                    string ghichu = txtghichu.Text;
                    string chucvu = cbchucvu.Text.ToString();
                    string bophan = cbbophan.Text.ToString();
                    string ngaysinh = txtngaysinh.Text;
                    string gioitinh = checkgioitinh();
                    string diachi = txtdiachi.Text;
                    string dienthoai = txtdienthoai.Text;
                    string hoso = txthoso.Text;

                    sua(id, ten, ghichu, chucvu, bophan, ngaysinh, gioitinh, diachi, dienthoai, hoso);
                    lblthongbao.Text = "Cập nhật dữ liệu thành công";
                    hien();
                }
            }
            catch (Exception ex)
            {
                lblthongbao.Text = "Lỗi, thử lại " + ex.Message.ToString();
                txtma.Focus();
            }
        }

        private void btnxoa_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Bạn có chắc muốn xóa dữ liệu? Dữ liệu sẽ bị mất và không thể phục hồi lại được.", "Xóa dữ liệu?", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                try
                {
                    if (int.Parse(txtma.Text) <= 0)
                    {
                        MessageBox.Show("Vui lòng chọn dữ liệu", "Thông báo!", MessageBoxButtons.OK);
                        lblthongbao.Text = "Chưa chọn dữ liệu.";
                    }
                    else
                    {
                        xoa(int.Parse(txtma.Text));
                        lblthongbao.Text = "Xóa dữ liệu thành công";
                        hien();
                    }
                }
                catch (Exception ex)
                {
                    lblthongbao.Text = "Lỗi, thử lại " + ex.Message.ToString();
                    txtma.Focus();
                }
            }
            else if (dialogResult == DialogResult.No)
            {
                txtma.Focus();
            }
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                txtma.Text = row.Cells[0].Value.ToString();
                txtten.Text = row.Cells[1].Value.ToString();
                txtghichu.Text = row.Cells[2].Value.ToString();


                cbchucvu.Text = row.Cells[3].Value.ToString();
                cbbophan.Text = row.Cells[4].Value.ToString();
                txtngaysinh.Text = row.Cells[5].Value.ToString();

                var _iche = row.Cells[6].Value.ToString();
                if (_iche == "NAM")
                {
                    rbnam.Checked = true;
                }
                else
                {
                    rbnam.Checked = true;
                }
                txtdiachi.Text = row.Cells[7].Value.ToString();
                txtdienthoai.Text = row.Cells[8].Value.ToString();
                txthoso.Text = row.Cells[9].Value.ToString();
            }
        }
        public string checkgioitinh()
        {
            var gioitinh = "";
            if (rbnam.Checked)
            {
                return gioitinh = rbnam.Text;
            }
            if (rbnu.Checked)
            {
                return gioitinh = rbnu.Text;
            }
            return gioitinh;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("" + checkgioitinh());  
        }

        private void frmnhanvien_Load(object sender, EventArgs e)
        {
            hien(); hien_bophan();
            hien_chucvu();
        }
        public void hien_chucvu()
        {
            var dt = ac.GetDataTable_Text("SELECT * FROM ACHUCVU");
            cbchucvu.DataSource = dt;
            cbchucvu.DisplayMember = "TEN";
            cbchucvu.ValueMember = "ID";
            // cbchucvu.SelectedIndex = 1;
        }
        public void hien_bophan()
        {
            var dt = ac.GetDataTable_Text("SELECT * FROM ABOPHAN");
            cbbophan.DataSource = dt;
            cbbophan.DisplayMember = "TEN";
            cbbophan.ValueMember = "ID";
            //  cbbophan.SelectedIndex = 1;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}

