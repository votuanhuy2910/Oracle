﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.DataAccess.Client;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace WindowsFormsApp3
{
    class DBUtils
    {

        public static OracleConnection GetDBConnection()
        {
            string host = "192.168.50.248";
            int port = 1521;
            string sid = "orcl";//orcl20 
            //orcl
            string user = "SYSTEM";// USER DEFAUL 
            string password = "@ABC123456";
    

            /// 
            return DBOracleUtils.GetDBConnection(host, port, sid, user, password);
        }
        public void ExecuteCommandtext(string query)
        {
            OracleConnection conn = DBUtils.GetDBConnection();
            conn.Open();
            OracleCommand cmd = new OracleCommand(query, conn);
            cmd.ExecuteNonQuery();
        }
        public DataTable GetDataTable_Text(string query)
        {
            try
            {
                OracleConnection conn = DBUtils.GetDBConnection();
                conn.Open();
                OracleCommand cmd = new OracleCommand(query, conn);
                DataTable result = new DataTable();
                OracleDataAdapter dapter = new OracleDataAdapter(cmd);
                dapter.Fill(result);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public DataTable GetDataTable_Store(string query)
        {
            try
            {
                OracleConnection conn = DBUtils.GetDBConnection();
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.CommandText = query;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                DataTable result = new DataTable();
                OracleDataAdapter dapter = new OracleDataAdapter(cmd);
                dapter.Fill(result);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public Boolean check_tontai(string tenbang, string tentruong, string giatri)
        {
            int c = 0;
            string sql = "select count(*) from " + tenbang + " where " + tentruong + " = '" + giatri + "' ";
            OracleCommand cmd = new OracleCommand();
            try
            {
                OracleConnection conn = DBUtils.GetDBConnection();
                conn.Open();
                cmd.CommandText = sql;
                cmd.Connection = conn;
                c = (int)cmd.ExecuteScalar();
                conn.Close();
                cmd.Dispose();
            }

            catch
            {
                return false;
            }

            return (c != 0);
        }
    }
}
