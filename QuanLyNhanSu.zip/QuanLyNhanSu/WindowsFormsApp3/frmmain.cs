﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class frmmain : Form
    {
        public frmmain()
        {
            InitializeComponent();
        }
        private void tHOÁTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        frmbophan frmbophan;
        frmchucvu frmchucvu;
        frmnhanvien frmnhanvien;

        private void mnnhanvien_Click(object sender, EventArgs e)
        {
            if (frmnhanvien == null)
            {

                frmnhanvien = new frmnhanvien();
                frmnhanvien.MdiParent = this;
                frmnhanvien.FormClosed += new FormClosedEventHandler(frmnhanvien_FormClosed);
                frmnhanvien.Show();
            }
            else
            {
                frmnhanvien.Activate();
            }
        }
        void frmnhanvien_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmnhanvien = null;
        }

        private void mnbophan_Click(object sender, EventArgs e)
        {
            if (frmbophan == null)
            {

                frmbophan = new frmbophan();
                frmbophan.MdiParent = this;
                frmbophan.FormClosed += new FormClosedEventHandler(frmbophan_FormClosed);
                frmbophan.Show();
            }
            else
            {
                frmbophan.Activate();
            }
        }
        void frmbophan_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmbophan = null;
        }

        private void mnchucvu_Click(object sender, EventArgs e)
        {
            if (frmchucvu == null)
            {

                frmchucvu = new frmchucvu();
                frmchucvu.MdiParent = this;
                frmchucvu.FormClosed += new FormClosedEventHandler(frmchucvu_FormClosed);
                frmchucvu.Show();
            }
            else
            {
                frmchucvu.Activate();
            }
        }
        void frmchucvu_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmchucvu = null;

        }

        private void tHÔNGTINToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("CHƯƠNG TRÌNH QUẢN LÝ NHÂN SỰ - C# và Oracle - Phát triển bởi H2KL", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
