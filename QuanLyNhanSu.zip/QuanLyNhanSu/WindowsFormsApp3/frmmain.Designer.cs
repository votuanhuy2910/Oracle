﻿namespace WindowsFormsApp3
{
    partial class frmmain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hỆTHỐNGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tHOÁTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnnhanvien = new System.Windows.Forms.ToolStripMenuItem();
            this.mnbophan = new System.Windows.Forms.ToolStripMenuItem();
            this.mnchucvu = new System.Windows.Forms.ToolStripMenuItem();
            this.tHÔNGTINToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hỆTHỐNGToolStripMenuItem,
            this.mnnhanvien,
            this.mnbophan,
            this.mnchucvu,
            this.tHÔNGTINToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1295, 28);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hỆTHỐNGToolStripMenuItem
            // 
            this.hỆTHỐNGToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tHOÁTToolStripMenuItem});
            this.hỆTHỐNGToolStripMenuItem.Image = global::WindowsFormsApp3.Properties.Resources.services_32px;
            this.hỆTHỐNGToolStripMenuItem.Name = "hỆTHỐNGToolStripMenuItem";
            this.hỆTHỐNGToolStripMenuItem.Size = new System.Drawing.Size(117, 24);
            this.hỆTHỐNGToolStripMenuItem.Text = "HỆ THỐNG";
            // 
            // tHOÁTToolStripMenuItem
            // 
            this.tHOÁTToolStripMenuItem.Image = global::WindowsFormsApp3.Properties.Resources.shutdown_24px;
            this.tHOÁTToolStripMenuItem.Name = "tHOÁTToolStripMenuItem";
            this.tHOÁTToolStripMenuItem.Size = new System.Drawing.Size(139, 26);
            this.tHOÁTToolStripMenuItem.Text = "THOÁT";
            this.tHOÁTToolStripMenuItem.Click += new System.EventHandler(this.tHOÁTToolStripMenuItem_Click);
            // 
            // mnnhanvien
            // 
            this.mnnhanvien.Image = global::WindowsFormsApp3.Properties.Resources.registration_32px;
            this.mnnhanvien.Name = "mnnhanvien";
            this.mnnhanvien.Size = new System.Drawing.Size(186, 24);
            this.mnnhanvien.Text = "QUẢN LÝ NHÂN VIÊN";
            this.mnnhanvien.Click += new System.EventHandler(this.mnnhanvien_Click);
            // 
            // mnbophan
            // 
            this.mnbophan.Image = global::WindowsFormsApp3.Properties.Resources.empty_box_24px;
            this.mnbophan.Name = "mnbophan";
            this.mnbophan.Size = new System.Drawing.Size(175, 24);
            this.mnbophan.Text = "QUẢN  LÝ BỘ PHẬN";
            this.mnbophan.Click += new System.EventHandler(this.mnbophan_Click);
            // 
            // mnchucvu
            // 
            this.mnchucvu.Image = global::WindowsFormsApp3.Properties.Resources.list_view_24px;
            this.mnchucvu.Name = "mnchucvu";
            this.mnchucvu.Size = new System.Drawing.Size(170, 24);
            this.mnchucvu.Text = "QUẢN LÝ CHỨC VỤ";
            this.mnchucvu.Click += new System.EventHandler(this.mnchucvu_Click);
            // 
            // tHÔNGTINToolStripMenuItem
            // 
            this.tHÔNGTINToolStripMenuItem.Image = global::WindowsFormsApp3.Properties.Resources.help_24px;
            this.tHÔNGTINToolStripMenuItem.Name = "tHÔNGTINToolStripMenuItem";
            this.tHÔNGTINToolStripMenuItem.Size = new System.Drawing.Size(121, 24);
            this.tHÔNGTINToolStripMenuItem.Text = "THÔNG TIN";
            this.tHÔNGTINToolStripMenuItem.Click += new System.EventHandler(this.tHÔNGTINToolStripMenuItem_Click);
            // 
            // frmmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApp3.Properties.Resources.CHƯƠNG_TRÌNH_QUẢN_LÝ_NHÂN_SỰ;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1295, 718);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.Name = "frmmain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QUẢN LÝ NHÂN SỰ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hỆTHỐNGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tHOÁTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnnhanvien;
        private System.Windows.Forms.ToolStripMenuItem mnbophan;
        private System.Windows.Forms.ToolStripMenuItem mnchucvu;
        private System.Windows.Forms.ToolStripMenuItem tHÔNGTINToolStripMenuItem;
    }
}