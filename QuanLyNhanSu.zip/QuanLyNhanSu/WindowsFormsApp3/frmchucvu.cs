﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess;
using Oracle.DataAccess.Client;
namespace WindowsFormsApp3
{
    public partial class frmchucvu : Form
    {
        public frmchucvu()
        {
            InitializeComponent();
        }
        DBUtils ac = new DBUtils();
        public void hien()
        {
            var dt = ac.GetDataTable_Text("SELECT * FROM ACHUCVU");
            dataGridView1.DataSource = dt;
            //return dt;
        }
        public void them(string ten, string ghichu)
        {
            string chuoi = " INSERT INTO ACHUCVU ";
            chuoi += " (ten,ghichu) ";
            chuoi += " VALUES ( ";
            chuoi += " N'" + ten + "',  ";
            chuoi += " N'" + ghichu + "') ";
            try
            {
                ac.ExecuteCommandtext(chuoi);
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }
        public void sua(int id, string ten, string ghichu)
        {
            string chuoi = " UPDATE  ACHUCVU SET ";
            chuoi += " ten= N'" + ten + "',  ";
            chuoi += " ghichu= N'" + ghichu + "'  ";
            chuoi += " WHERE id = N'" + id + "' ";
            try
            {
                ac.ExecuteCommandtext(chuoi);
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }
        public void xoa(int id)
        {
            string chuoi = "DELETE  FROM ACHUCVU   ";
            chuoi += " WHERE id = N'" + id + "' ";
            try
            {
                ac.ExecuteCommandtext(chuoi);
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }

        private void btnthem_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtten.Text == null)
                {
                    MessageBox.Show("Vui lòng nhập dữ liệu", "Thông báo!", MessageBoxButtons.OK);
                    txtten.Focus();
                    lblthongbao.Text = "Chưa có dữ liệu.";
                }
                else
                {
                    them(txtten.Text, txtghichu.Text);
                    hien();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex.ToString());
            }

        }

        private void btnhien_Click(object sender, EventArgs e)
        {
            hien();
        }

        private void btnsua_Click(object sender, EventArgs e)
        {
            try
            {
                if (int.Parse(txtma.Text) <= 0)
                {
                    MessageBox.Show("Vui lòng chọn dữ liệu", "Thông báo!", MessageBoxButtons.OK);
                    lblthongbao.Text = "Chưa chọn dữ liệu.";
                }
                else
                {
                    sua(int.Parse(txtma.Text), txtten.Text, txtghichu.Text);
                    lblthongbao.Text = "Cập nhật dữ liệu thành công";
                    hien();
                }
            }
            catch (Exception ex)
            {
                lblthongbao.Text = "Lỗi, thử lại " + ex.Message.ToString();
                txtma.Focus();
            }
        }

        private void btnxoa_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Bạn có chắc muốn xóa dữ liệu? Dữ liệu sẽ bị mất và không thể phục hồi lại được.", "Xóa dữ liệu?", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                try
                {
                    if (int.Parse(txtma.Text) <= 0)
                    {
                        MessageBox.Show("Vui lòng chọn dữ liệu", "Thông báo!", MessageBoxButtons.OK);
                        lblthongbao.Text = "Chưa chọn dữ liệu.";
                    }
                    else
                    {
                        xoa(int.Parse(txtma.Text));
                        lblthongbao.Text = "Xóa dữ liệu thành công";
                        hien();
                    }
                }
                catch (Exception ex)
                {
                    lblthongbao.Text = "Lỗi, thử lại " + ex.Message.ToString();
                    txtma.Focus();
                }
            }
            else if (dialogResult == DialogResult.No)
            {
                txtma.Focus();
            }
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                txtma.Text = row.Cells[0].Value.ToString();
                txtten.Text = row.Cells[1].Value.ToString();
                txtghichu.Text = row.Cells[2].Value.ToString();
                // int _iche = int.Parse(row.Cells[3].Value.ToString());
                //if (_iche < 1)
                //{
                //    check_trangthai.Checked = false;
                //}
                //else
                //{
                //    check_trangthai.Checked = true;
                //}
            }
        }

        private void frmchucvu_Load(object sender, EventArgs e)
        {
            hien();
        }
    }
}
