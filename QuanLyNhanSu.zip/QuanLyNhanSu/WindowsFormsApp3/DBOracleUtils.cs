﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.DataAccess.Client;
namespace WindowsFormsApp3
{
    class DBOracleUtils
    {
        public static OracleConnection
            GetDBConnection(string host, int port, String sid, String user, String password)
        {
            // Connection String để kết nối trực tiếp tới Oracle.
            string connString = "Data Source=(DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = "
                 + host + ")(PORT = " + port + "))(CONNECT_DATA = (SERVER = DEDICATED)(SERVICE_NAME = "
                 + sid + ")));Password=" + password + ";User ID=" + user;
            string chuoi = @"Data source= orcl;user id=system; password=12345678;";
            OracleConnection conn = new OracleConnection();
            conn.ConnectionString = chuoi;
            return conn;
        }
    }
}
